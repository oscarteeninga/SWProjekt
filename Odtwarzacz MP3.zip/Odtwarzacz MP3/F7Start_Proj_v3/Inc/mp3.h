#ifndef _MP3_H_
#define _MP3_H_
#include "mp3dec.h"
struct mp3_decoder {
    HMP3Decoder     decoder;
    MP3FrameInfo    frame_info;
    uint32_t        frames;
    uint32_t        (*fetch_data)(void *parameter,
                                  uint8_t *buffer,
                                  uint32_t length);
    void            *fetch_parameter;
    uint8_t         *read_buffer, *read_ptr;
    int32_t         read_offset;
    uint32_t        bytes_left;
    uint32_t        (*output_cb)(MP3FrameInfo *header,
                                 int16_t *buffer,
                                 uint32_t length);
};

void mp3_decoder_init(struct mp3_decoder *decoder);
void mp3_decoder_detach(struct mp3_decoder *decoder);
struct mp3_decoder *mp3_decoder_create(void);
void mp3_decoder_delete(struct mp3_decoder *decoder);
int mp3_decoder_run(struct mp3_decoder *decoder);
void mp3_set_speed(float speed);
int mp3_decoder_run_pvc(struct mp3_decoder *decoder);
int mp3_bpm_detect_run(struct mp3_decoder *decoder);
#endif
